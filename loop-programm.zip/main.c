/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/


#include<stdio.h>
#include<conio.h>

int main()
{
	int i,d,choice;
	char c='y';
	
	 while(c=='y')
	 {
	 	printf("\nWhile loop-->1  \nDo while loop-->2 \nFor loop-->3 \n ");
	 	printf("Enter the choice of operation \n");
	 	scanf("%d",&choice);
	 	printf("Enter the values of starting numbers and ending numbers:-");
	 	scanf("%d%d",&i,&d);
	 	switch(choice)
	 	{
	 		case 1:
	 			    while (i<=d)
	 			    {
	 			    	printf("%d\n",i);
	 			    	i++ ;
					 }
			break;
			
			case 2: 
					do
					 {
					 	printf("%d\n",i);
					 	i++;
					   } 
					 while(i<=d);
				
		    break;
				
			case 3:	
			        for(i; i<=d; i++)
			        {
			        	printf("%d\n",i);
					}
			break;
			
			   default: printf("\n wrong choice");		
				
		 }
		 printf("\n Do you want to conitnue : Y / N");
		 c=getch();
	 }
	 getch();
}